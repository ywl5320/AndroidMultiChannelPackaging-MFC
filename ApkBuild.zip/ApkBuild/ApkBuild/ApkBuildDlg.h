﻿
// ApkBuildDlg.h : 头文件
//

#pragma once
#include "afxwin.h"
#include "afxcmn.h"

#define WM_STATE  (WM_USER + 100)     //自定义消息响应类型
#define WM_BUILD  (WM_USER + 110)     //自定义消息响应类型
#define WM_SIGN  (WM_USER + 120)     //自定义消息响应类型

struct KeystoreInfo
{
	CString keystorePath;//keystore路径
	CString keystorePass;//别名密码
	int from;//0 只获取别名
	HWND         hWnd;//主窗口句柄，用于消息的发送
};

struct DecodeApkInfo
{
	CString apkPath;//apk文件路径
	HWND         hWnd;//主窗口句柄，用于消息的发送
};

struct BuildApkInfo
{
	CString fileName;//渠道名字
	CString name;//渠道名字
	HWND    hWnd;//主窗口句柄，用于消息的发送
};

struct SinageApkInfo
{
	CString name;//渠道名字
	CString fileName;
	CString keyPass;
	CString keyalis;
	CString keystoreName;
	HWND    hWnd;//主窗口句柄，用于消息的发送
};

// CApkBuildDlg 对话框
class CApkBuildDlg : public CDialogEx
{
// 构造
public:
	CApkBuildDlg(CWnd* pParent = NULL);	// 标准构造函数

// 对话框数据
	enum { IDD = IDD_APKBUILD_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 支持


// 实现
protected:
	HICON m_hIcon;

	KeystoreInfo keyinfo;
	DecodeApkInfo decodeapkinfo;
	BuildApkInfo buildapkinfo;
	SinageApkInfo sinageapkinfo;

	char *channel;
	char *channelNext;

	int progressStep;
	int currentStep;
	bool isRun = false;

	// 生成的消息映射函数
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtest();
	CString CApkBuildDlg::ApkOpenDialog();
	CString CApkBuildDlg::KeyStoreOpenDialog();
	CString CApkBuildDlg::GetAllChannelDialog();
	char* CApkBuildDlg::CStringToChar(CString &str);
	CString CApkBuildDlg::CharToCString(char *c);
	void CApkBuildDlg::DeleteDirectory(CString strDir);
	int CApkBuildDlg::GetProgressStep(CString channelId);
	void CApkBuildDlg::GetChannelNames();
	void CApkBuildDlg::CompressionApk();
	int CApkBuildDlg::IncludeChinese(char *str);
	//void CApkBuildDlg::MulityBuildApkd(CString apkpath, CString channelId);
	LRESULT CApkBuildDlg::UpdateState(WPARAM wParam, LPARAM lParam);//自定义消息响应函数​
	LRESULT CApkBuildDlg::BuildChannelApks(WPARAM wParam, LPARAM lParam);//自定义消息响应函数​
	LRESULT CApkBuildDlg::SinageChannelApks(WPARAM wParam, LPARAM lParam);//自定义消息响应函数​
	afx_msg void OnBnClickedChoiceFile();
	CEdit ePath;
	CString fileName;
	CString keystoreName;
	afx_msg void OnBnClickedButton1();
	CEdit eChannelID;
	afx_msg void OnBnClickedButton4();
	afx_msg void OnBnClickedButton2();
	CEdit eKeyStore;
	CEdit eKeystorePass;
	CEdit eKeystoreAlis;
	afx_msg void OnBnClickedButton3();
	CEdit eKeystoreBPass;

	static void CApkBuildDlg::GetKeystoreAlis(LPVOID lpParam);

	static void CApkBuildDlg::DcodeApks(LPVOID lpParam);

	static void CApkBuildDlg::BuildApks(LPVOID lpParam);

	static void CApkBuildDlg::SinageApks(LPVOID lpParam);


	CProgressCtrl barProgress;
	CComboBox cbChannelName;
	afx_msg void OnBnClickedChannelname();
};
