
// ApkBuildDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "ApkBuild.h"
#include "ApkBuildDlg.h"
#include "afxdialogex.h"
#include "stdio.h"
#include "tinyxml2.h"  
#include <iostream>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace tinyxml2;
using namespace std;


// ����Ӧ�ó��򡰹��ڡ��˵���� CAboutDlg �Ի���

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// �Ի�������
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

// ʵ��
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CApkBuildDlg �Ի���



CApkBuildDlg::CApkBuildDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CApkBuildDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CApkBuildDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, ePath);
	DDX_Control(pDX, IDC_EDIT2, eChannelID);
	DDX_Control(pDX, IDC_EDIT3, eKeyStore);
	DDX_Control(pDX, IDC_EDIT4, eKeystorePass);
	DDX_Control(pDX, IDC_EDIT6, eKeystoreAlis);
	DDX_Control(pDX, IDC_EDIT5, eKeystoreBPass);
	DDX_Control(pDX, IDC_PENCENT, barProgress);
	DDX_Control(pDX, IDC_COMBO1, cbChannelName);
}

BEGIN_MESSAGE_MAP(CApkBuildDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()

	ON_BN_CLICKED(IDC_CHOICE_FILE, &CApkBuildDlg::OnBnClickedChoiceFile)

	ON_BN_CLICKED(IDC_BUTTON4, &CApkBuildDlg::OnBnClickedButton4)
	ON_BN_CLICKED(IDC_BUTTON2, &CApkBuildDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &CApkBuildDlg::OnBnClickedButton3)

	ON_MESSAGE(WM_STATE, &CApkBuildDlg::UpdateState)
	ON_MESSAGE(WM_BUILD, &CApkBuildDlg::BuildChannelApks)
	ON_MESSAGE(WM_SIGN, &CApkBuildDlg::SinageChannelApks)

	ON_BN_CLICKED(IDC_CHANNELNAME, &CApkBuildDlg::OnBnClickedChannelname)
END_MESSAGE_MAP()


// CApkBuildDlg ��Ϣ��������

BOOL CApkBuildDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// ��������...���˵������ӵ�ϵͳ�˵��С�

	// IDM_ABOUTBOX ������ϵͳ���Χ�ڡ�
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// ���ô˶Ի����ͼ�ꡣ  ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO:  �ڴ����Ӷ���ĳ�ʼ������
	barProgress.SetRange(0, 100);
	barProgress.SetStep(1);

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

void CApkBuildDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ  ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CApkBuildDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CApkBuildDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


/*
	ѡ��apk�ļ��Ի���
*/
CString CApkBuildDlg::ApkOpenDialog()
{
	CString strFile = _T("");
	fileName = _T("");
	CFileDialog dlgFile(TRUE, NULL, NULL, OFN_HIDEREADONLY, _T("Describe Files (*.APK)|*.apk"), NULL);
	if (dlgFile.DoModal())
	{
		strFile = dlgFile.GetPathName();
		fileName = dlgFile.GetFileName();
		fileName = fileName.Left(fileName.GetLength() - 4);
	}

	return strFile;
}

/*
	ѡ��keystore�Ի���
*/
CString CApkBuildDlg::KeyStoreOpenDialog()
{
	CString strFile = _T("");
	CFileDialog dlgFile(TRUE, NULL, NULL, OFN_HIDEREADONLY, _T("Describe Files (*.keystore)|*.jks"), NULL);
	if (dlgFile.DoModal())
	{
		strFile = dlgFile.GetPathName();
		keystoreName = dlgFile.GetFileName();
	}

	return strFile;
}

CString CApkBuildDlg::GetAllChannelDialog()
{
	CString strFile = _T("");
	CFileDialog dlgFile(TRUE, NULL, NULL, OFN_HIDEREADONLY, _T("Describe Files (*.txt)|*.TXT"), NULL);
	if (dlgFile.DoModal())
	{
		strFile = dlgFile.GetPathName();
		keystoreName = dlgFile.GetFileName();
	}

	return strFile;
}



void CApkBuildDlg::OnBnClickedChoiceFile()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	if (isRun)
	{
		return;
	}
	
	CString filepath = ApkOpenDialog();
	if (IncludeChinese(CStringToChar(fileName)) == 1)
	{
		MessageBox(_T("��ѡ�񲻰�������������Ϸ��"), _T("��ʾ"));
		return;
	}
	ePath.SetWindowTextW(filepath);
	cbChannelName.ResetContent();
	if (filepath != _T(""))
	{
		barProgress.SetPos(0);
		GetChannelNames();
	}
}


void CApkBuildDlg::OnBnClickedButton4()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	if (isRun)
	{
		return;
	}

	

	CString apkPath;
	ePath.GetWindowTextW(apkPath);
	if (apkPath == _T(""))
	{
		MessageBox(_T("����ѡ����Ϸ��"), _T("��ʾ"));
		return;
	}
	int nIndex = cbChannelName.GetCurSel();
	if (nIndex >= 0)
	{
		CString strCBText;
		cbChannelName.GetLBText(nIndex, strCBText);
		DeleteDirectory(fileName);
		if (strCBText == _T(""))
		{
			MessageBox(_T("��apk����û������������"), _T("��ʾ"));
			return;
		}
	}
	else
	{
		MessageBox(_T("��apk����û������������"), _T("��ʾ"));
		return;
	}
	

	CString channelId;
	eChannelID.GetWindowTextW(channelId);
	if (channelId == _T(""))
	{
		MessageBox(_T("����д������Ϣ"), _T("��ʾ"));
		return;
	}
	
	CString keystorePath;
	eKeyStore.GetWindowTextW(keystorePath);
	if (keystorePath == _T(""))
	{
		MessageBox(_T("��ѡ��keystore"), _T("��ʾ"));
		return;
	}
	CString keystorePass;
	eKeystorePass.GetWindowTextW(keystorePass);
	if (keystorePass == _T(""))
	{
		MessageBox(_T("������keystore����"), _T("��ʾ"));
		return;
	}
	CString keystoreBPass;
	eKeystoreBPass.GetWindowTextW(keystoreBPass);
	if (keystoreBPass == _T(""))
	{
		MessageBox(_T("������keystore����"), _T("��ʾ"));
		return;
	}
	CString keystoreAlis;
	eKeystoreAlis.GetWindowTextW(keystoreAlis);
	if (keystoreAlis == _T(""))
	{
		isRun = true;
		currentStep = 5;
		barProgress.SetPos(currentStep);
		GetDlgItem(ID_STATE)->SetWindowText(_T("��ȡkeystore����"));
		keyinfo.keystorePath = keystorePath;
		keyinfo.keystorePass = keystorePass;
		keyinfo.hWnd = m_hWnd;
		keyinfo.from = 1;
		AfxBeginThread((AFX_THREADPROC)GetKeystoreAlis, &keyinfo);
	}
	else
	{
		isRun = true;
		currentStep = 5;
		barProgress.SetPos(currentStep);
		GetDlgItem(ID_STATE)->SetWindowText(_T("���ڽ�ѹapk��"));
		DeleteDirectory(fileName);
		CString apkPath;
		ePath.GetWindowTextW(apkPath);
		decodeapkinfo.apkPath = apkPath;
		decodeapkinfo.hWnd = m_hWnd;
		AfxBeginThread((AFX_THREADPROC)DcodeApks, &decodeapkinfo);
	}

}

char* CApkBuildDlg::CStringToChar(CString &str)
{
	CString result = CString(str);

	int len = WideCharToMultiByte(CP_ACP, 0, result, -1, NULL, 0, NULL, NULL);
	char *cstr = new char[len + 1];
	WideCharToMultiByte(CP_ACP, 0, result, -1, cstr, len, NULL, NULL);
	return cstr;

}

CString CApkBuildDlg::CharToCString(char *c)
{
	CString string;
	string.Format(_T("%s"), CStringW(c)); 
	return string;
}


void CApkBuildDlg::OnBnClickedButton2()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	if (isRun)
	{
		return;
	}
	CString gkeystorepath = KeyStoreOpenDialog();
	eKeyStore.SetWindowTextW(gkeystorepath);
}


void CApkBuildDlg::OnBnClickedButton3()
{
	if (isRun)
	{
		return;
	}
	
	CString kpath;
	eKeyStore.GetWindowTextW(kpath);
	CString kpass;
	eKeystorePass.GetWindowTextW(kpass);

	if (kpath == _T(""))
	{
		MessageBox(_T("��ѡ��keystore"), _T("��ʾ"));
		return;
	}
	if (kpass == _T(""))
	{
		MessageBox(_T("������keystore����"), _T("��ʾ"));
		return;
	}
	isRun = true;
	keyinfo.keystorePath = kpath;
	keyinfo.keystorePass = kpass;
	keyinfo.hWnd = m_hWnd;
	keyinfo.from = 0;
	AfxBeginThread((AFX_THREADPROC)GetKeystoreAlis, &keyinfo);
	GetDlgItem(ID_STATE)->SetWindowText(_T("��ȡkeystore����"));
}


void CApkBuildDlg::DeleteDirectory(CString strDir)
{
	if (strDir.IsEmpty())
	{
		RemoveDirectory(strDir);
		return;
	}
	//����ɾ���ļ������ļ��� 
	CFileFind   ff;
	BOOL bFound = ff.FindFile(strDir + _T("\\*"),0);
	while (bFound)
	{
		bFound = ff.FindNextFile();
		if (ff.GetFileName() == _T(".") || ff.GetFileName() == _T(".."))
			continue;
		//ȥ���ļ�(��)ֻ�������� 
		SetFileAttributes(ff.GetFilePath(), FILE_ATTRIBUTE_NORMAL);
		if (ff.IsDirectory())
		{
			//�ݹ�ɾ�����ļ��� 
			DeleteDirectory(ff.GetFilePath());
			RemoveDirectory(ff.GetFilePath());
		}
		else
		{
			DeleteFile(ff.GetFilePath());   //ɾ���ļ� 
		}
	}
	ff.Close();
	//Ȼ��ɾ�����ļ��� 
	RemoveDirectory(strDir);

}


//��ȡkeystore����
void CApkBuildDlg::GetKeystoreAlis(LPVOID lpParam)
{
	KeystoreInfo * keystoreinfo = (KeystoreInfo*)lpParam;
	CApkBuildDlg *dlg = (CApkBuildDlg *)keystoreinfo->hWnd;
	CString cmd1 = _T("keytool -list -v -keystore ");
	CString cmd2 = _T(" -storepass ");
	CString cmd3 = _T(" > keysinfo.txt");
	CString kcmd = cmd1 + keystoreinfo->keystorePath + cmd2 + keystoreinfo->keystorePass + cmd3;

	char *ckcmd = dlg->CStringToChar(kcmd);
	int state2 = system(ckcmd);

	if (state2 == 0)
	{
		if (keystoreinfo->from == 0)
		{
			::PostMessage(keystoreinfo->hWnd, WM_STATE, (WPARAM)"��ȡ�����ɹ�", -1);
		}
		else
		{
			::PostMessage(keystoreinfo->hWnd, WM_STATE, (WPARAM)"��ȡ�����ɹ�", 0);
		}
		
	}
	else
	{
		::PostMessage(keystoreinfo->hWnd, WM_STATE, (WPARAM)"��ȡ����ʧ�ܣ���ȷ��keystore�Ƿ���ȷ", 1);
	}
}

//��ѹapk��
void CApkBuildDlg::DcodeApks(LPVOID lpParam)
{
	DecodeApkInfo * decodeapkinfo = (DecodeApkInfo*)lpParam;
	CApkBuildDlg *dlg = (CApkBuildDlg *)decodeapkinfo->hWnd;
	CString scmd = _T("apktool apktool d ");
	CString dapkcmd = scmd + decodeapkinfo->apkPath;
	int state = system(dlg->CStringToChar(dapkcmd));
	if (state == 0)
	{
		::PostMessage(decodeapkinfo->hWnd, WM_STATE, (WPARAM)"apk����ѹ�ɹ�", 2);
	}
	else
	{
		::PostMessage(decodeapkinfo->hWnd, WM_STATE, (WPARAM)"apk����ѹʧ��", 3);
	}
}

void CApkBuildDlg::BuildApks(LPVOID lpParam)
{
	BuildApkInfo * buildapkinfo = (BuildApkInfo*)lpParam;
	CApkBuildDlg *dlg = (CApkBuildDlg *)buildapkinfo->hWnd;
	CString bcmd = _T("apktool b ");
	CString bkg = _T(" -o ");
	CString bapk = _T(".apk");
	CString bcmdapk = bcmd + buildapkinfo->fileName + bkg + buildapkinfo->fileName + buildapkinfo->name + bapk;
	char *cbcmd = dlg->CStringToChar(bcmdapk);
	CString string;
	string.Format(_T("%s"), CStringW(cbcmd)); //��������װ���ַ�����
	//MessageBox(string);

	int state = system(cbcmd);
	if (state == 0)
	{

		::PostMessage(buildapkinfo->hWnd, WM_BUILD, (WPARAM)"apk����ɹ�", 0);
	}
	else
	{
		::PostMessage(buildapkinfo->hWnd, WM_BUILD, (WPARAM)"apk���ʧ��", 1);
	}
}

void CApkBuildDlg::SinageApks(LPVOID lpParam)
{
	SinageApkInfo * sinageapkinfo = (SinageApkInfo*)lpParam;
	CApkBuildDlg *dlg = (CApkBuildDlg *)sinageapkinfo->hWnd;

	//jarsigner -verbose -digestalg SHA1 -sigalg MD5withRSA -keystore bdgames.jks -tsa https://timestamp.geotrust.com/tsa -storepass bdgames001 -signedjar app-release�㶹��.apk app-release�㶹��.apk bdgames
	CString bscmd1 = _T("jarsigner -verbose -digestalg SHA1 -sigalg MD5withRSA -keystore ");
	//CString bscmd2 = _T(" -tsa https://timestamp.geotrust.com/tsa -storepass ");
	CString bscmd2 = _T(" -storepass ");
	CString bscmd3 = _T(" -signedjar ");
	CString bapk = _T(".apk");
	
	CString bscmd4 = _T(" ");

	CString bscmd = bscmd1 + sinageapkinfo->keystoreName + bscmd2 + sinageapkinfo->keyPass + bscmd3 + sinageapkinfo->fileName + sinageapkinfo->name + bapk + bscmd4 + sinageapkinfo->fileName + sinageapkinfo->name + bapk + sinageapkinfo->keyalis;
	//MessageBox(bscmd);
	int bsstate = system(dlg->CStringToChar(bscmd));
	if (bsstate == 0)
	{
		CString zcmd1 = _T("zipalign 4 ");
		CString zcmd2 = _T(" ");
		CString zcmd3 = _T("_Signed");
		CString zcmd = zcmd1 + sinageapkinfo->fileName + sinageapkinfo->name + bapk + zcmd2 + sinageapkinfo->fileName + sinageapkinfo->name + zcmd3 + bapk;

		int zstate = system(dlg->CStringToChar(zcmd));
		if (zstate == 0)
		{

			::PostMessage(sinageapkinfo->hWnd, WM_SIGN, (WPARAM)dlg->CStringToChar(sinageapkinfo->name), 0);
		}
		else
		{
			::PostMessage(sinageapkinfo->hWnd, WM_SIGN, (WPARAM)dlg->CStringToChar(sinageapkinfo->name), 1);
		}
	}
	else
	{
		::PostMessage(sinageapkinfo->hWnd, WM_SIGN, (WPARAM)dlg->CStringToChar(sinageapkinfo->name), 1);
	}

}


/*
	wParam:note
	lParam:0����ȡ�����ɹ� 1����ȡ����ʧ��
*/
LRESULT CApkBuildDlg::UpdateState(WPARAM wParam, LPARAM lParam)
{
	if (lParam == -1)
	{
		CFile fFile(_T("keysinfo.txt"), CFile::modeRead);
		CStringA strFile;
		fFile.Read(strFile.GetBufferSetLength(fFile.GetLength()), fFile.GetLength());
		fFile.Close();
		strFile.ReleaseBuffer();
		CString result = CString(strFile);
		char *xmlpath = CStringToChar(result);
		char *pNext = NULL;
		char *p = strtok_s(xmlpath, "\n", &pNext);
		while (p)
		{
			CString string;
			string.Format(_T("%s"), CStringW(p)); //��������װ���ַ�����
			int index = string.Find(_T("����: "));
			if (index == 0)
			{
				string = string.Right(string.GetLength() - 3);
				eKeystoreAlis.SetWindowTextW(string);
			}
			p = strtok_s(NULL, "\n", &pNext);
		}

		CString alis;
		eKeystoreAlis.GetWindowTextW(alis);
		if (alis == _T(""))
		{
			MessageBox(_T("��ȡkeystore����ʧ�ܣ���ȷ��Keystore�����Ƿ���ȷ"), _T("��ʾ"));
			isRun = false;
		}
		else
		{
			GetDlgItem(ID_STATE)->SetWindowText(_T("��ȡkeystore�����ɹ�"));
			DeleteFile(_T("keysinfo.txt"));
			isRun = false;
		}
	}
	else if (lParam == 0)
	{
		CFile fFile(_T("keysinfo.txt"), CFile::modeRead);
		CStringA strFile;
		fFile.Read(strFile.GetBufferSetLength(fFile.GetLength()), fFile.GetLength());
		fFile.Close();
		strFile.ReleaseBuffer();
		CString result = CString(strFile);
		char *xmlpath = CStringToChar(result);
		char *pNext = NULL;
		char *p = strtok_s(xmlpath, "\n", &pNext);
		while (p)
		{
			CString string;
			string.Format(_T("%s"), CStringW(p)); //��������װ���ַ�����
			int index = string.Find(_T("����: "));
			if (index == 0)
			{
				string = string.Right(string.GetLength() - 3);
				eKeystoreAlis.SetWindowTextW(string);
			}
			p = strtok_s(NULL, "\n", &pNext);
		}

		CString alis;
		eKeystoreAlis.GetWindowTextW(alis);
		if (alis == _T(""))
		{
			isRun = false;
			MessageBox(_T("��ȡkeystore����ʧ�ܣ���ȷ��Keystore�����Ƿ���ȷ"), _T("��ʾ"));
		}
		else
		{
			DeleteFile(_T("keysinfo.txt"));
			currentStep = 5;
			barProgress.SetPos(currentStep);
			GetDlgItem(ID_STATE)->SetWindowText(_T("���ڽ�ѹapk��"));
			DeleteDirectory(fileName);
			CString apkPath;
			ePath.GetWindowTextW(apkPath);
			decodeapkinfo.apkPath = apkPath;
			decodeapkinfo.hWnd = m_hWnd;
			AfxBeginThread((AFX_THREADPROC)DcodeApks, &decodeapkinfo);
		}
	}
	else if (lParam == 1)
	{
		char *str = (char *)wParam;
		MessageBox(CharToCString(str), _T("��ʾ"));
	}
	else if (lParam == 2)
	{
		//MessageBox(_T("��ѹ�ɹ���"), _T("��ʾ"), MB_ICONEXCLAMATION);//��ʾʧ��
		GetDlgItem(ID_STATE)->SetWindowText(_T("apk����ѹ�ɹ�"));
		CompressionApk();
		currentStep = 10;
		barProgress.SetPos(currentStep);
		CString channelId;
		eChannelID.GetWindowTextW(channelId);
		int count = GetProgressStep(channelId);
		progressStep = 88 / count;

		channelNext = NULL;
		channel = NULL;
		channel = strtok_s(CStringToChar(channelId), "\n", &channelNext);
		if (channel)
		{

			int nIndex = cbChannelName.GetCurSel();
			CString strCBText;
			cbChannelName.GetLBText(nIndex, strCBText);

			CString s = CharToCString(channel);

			char *spNext = NULL;
			char *sp = strtok_s(CStringToChar(s), ":", &spNext);

			CString name = CharToCString(sp);
			sp = strtok_s(NULL, ":", &spNext);
			CString id = CharToCString(sp);
			//MessageBox(_T("���ڴ������:" + name), _T("��ʾ"), MB_ICONEXCLAMATION);//��ʾʧ��
			GetDlgItem(ID_STATE)->SetWindowText(_T("������������:" + name));
			//���в���������
			//CString cbstate = _T("���ڴ������:" + name);
			//eBuildState.SetWindowTextW(cbstate);
			//MessageBox(id);
			CString manfpath = _T("/AndroidManifest.xml");
			CString sxmlpath = fileName + manfpath;
			char *xmlpath = CStringToChar(sxmlpath);
			tinyxml2::XMLDocument doc;
			doc.LoadFile(xmlpath);

			tinyxml2::XMLElement *RootElement = doc.RootElement();//���Ը�Ԫ��
			tinyxml2::XMLElement *RootSubElements = RootElement->FirstChildElement();//��һ����Ԫ��
			while (RootSubElements)
			{
				const char* application = RootSubElements->Value();
				CString apli;
				apli.Format(_T("%s"), CStringW(application)); //��������װ���ַ�����
				if (apli == "application")
				{
					tinyxml2::XMLElement *elements = RootSubElements->FirstChildElement();//appli

					while (elements)
					{
						const char* metadata = elements->Value();
						CString string;
						string.Format(_T("%s"), CStringW(metadata)); //��������װ���ַ�����
						if (string == "meta-data")//�ҵ���meta-data�ڵ�
						{
							const tinyxml2::XMLAttribute *attr = elements->FirstAttribute();
							while (attr)
							{
								const char* name = attr->Name();
								const char* value = attr->Value();
								CString cname;
								CString cvalue;
								cname.Format(_T("%s"), CStringW(name));
								cvalue.Format(_T("%s"), CStringW(value));

								if (cname == "android:name" && cvalue == strCBText)
								{
									//MessageBox(cvalue);
									elements->SetAttribute("android:value", CStringToChar(id));
									break;
								}
								attr = attr->Next();

							}

						}
						elements = elements->NextSiblingElement();
					}

					doc.SaveFile(xmlpath);
					GetDlgItem(ID_STATE)->SetWindowText(_T("���ڴ������:" + name));
					buildapkinfo.fileName = fileName;
					buildapkinfo.name = name;
					buildapkinfo.hWnd = m_hWnd;

					CString zcmd3 = _T("_Signed");
					CString bapk = _T(".apk");
					DeleteFile(fileName + name + zcmd3 + bapk);

					AfxBeginThread((AFX_THREADPROC)BuildApks, &buildapkinfo);
					break;
				}
				RootSubElements = RootSubElements->NextSiblingElement();
			}

			














			/*
			tinyxml2::XMLElement *RootElement = doc.RootElement();//man
			tinyxml2::XMLElement *elements = RootElement->FirstChildElement()->FirstChildElement();//appli

			while (elements)
			{
				const char* metadata = elements->Value();
				CString string;
				string.Format(_T("%s"), CStringW(metadata)); //��������װ���ַ�����
				if (string == "meta-data")//�ҵ���meta-data�ڵ�
				{
					const tinyxml2::XMLAttribute *attr = elements->FirstAttribute();
					while (attr)
					{
						const char* name = attr->Name();
						const char* value = attr->Value();
						CString cname;
						CString cvalue;
						cname.Format(_T("%s"), CStringW(name));
						cvalue.Format(_T("%s"), CStringW(value));

						if (cname == "android:name" && cvalue == strCBText)
						{
							//MessageBox(cvalue);
							elements->SetAttribute("android:value", CStringToChar(id));
						}
						attr = attr->Next();

					}

				}
				elements = elements->NextSiblingElement();
			}
			*/
			
		}
		else
		{
			isRun = false;
			char *str = (char *)wParam;
			MessageBox(CharToCString(str), _T("��ʾ"));
		}

	}
	else if (lParam == 3)
	{
		isRun = false;
		char *str = (char *)wParam;
		MessageBox(CharToCString(str), _T("��ʾ"));
	}

	return 0;
}

LRESULT CApkBuildDlg::BuildChannelApks(WPARAM wParam, LPARAM lParam)
{

	if (lParam == 0)
	{
		if (channel)
		{

			CString s = CharToCString(channel);

			char *spNext = NULL;
			char *sp = strtok_s(CStringToChar(s), ":", &spNext);

			CString name = CharToCString(sp);
			sp = strtok_s(NULL, ":", &spNext);
			CString id = CharToCString(sp);

			//MessageBox(_T("����ǩ��:" + name), _T("��ʾ"), MB_ICONEXCLAMATION);//��ʾʧ��
			GetDlgItem(ID_STATE)->SetWindowText(_T("����ǩ������:" + name));
			CString keyPass;
			eKeystoreBPass.GetWindowTextW(keyPass);
			CString keyalis;
			eKeystoreAlis.GetWindowTextW(keyalis);
			CString keypath;
			eKeyStore.GetWindowTextW(keypath);

			sinageapkinfo.fileName = fileName;
			sinageapkinfo.name = name;
			sinageapkinfo.hWnd = m_hWnd;
			sinageapkinfo.keyalis = keyalis;
			sinageapkinfo.keyPass = keyPass;
			sinageapkinfo.keystoreName = keypath;
			AfxBeginThread((AFX_THREADPROC)SinageApks, &sinageapkinfo);
		}

	}
	else
	{
		isRun = false;
		char *str = (char *)wParam;
		GetDlgItem(ID_STATE)->SetWindowText(CharToCString(str));
		//DeleteDirectory(fileName);
		barProgress.SetPos(100);
		MessageBox(CharToCString(str), _T("��ʾ"));
	}

	return 0;
}

LRESULT CApkBuildDlg::SinageChannelApks(WPARAM wParam, LPARAM lParam)
{
	if (lParam == 0)
	{
		char *name = (char *)wParam;
		CString result = CharToCString(name) + CharToCString("��������ɹ�");
		GetDlgItem(ID_STATE)->SetWindowText(result);
		CString bapk = _T(".apk");
		DeleteFile(fileName + name + bapk);
		channel = strtok_s(NULL, "\n", &channelNext);
		currentStep = currentStep + progressStep;
		barProgress.SetPos(currentStep);
		if (channel)
		{
			int nIndex = cbChannelName.GetCurSel();
			CString strCBText;
			cbChannelName.GetLBText(nIndex, strCBText);

			CString s = CharToCString(channel);

			char *spNext = NULL;
			char *sp = strtok_s(CStringToChar(s), ":", &spNext);

			CString name = CharToCString(sp);
			sp = strtok_s(NULL, ":", &spNext);
			CString id = CharToCString(sp);


			//���в���������
			//CString cbstate = _T("���ڴ������:" + name);
			//eBuildState.SetWindowTextW(cbstate);
			//MessageBox(id);
			GetDlgItem(ID_STATE)->SetWindowText(_T("������������:" + name));
			CString manfpath = _T("/AndroidManifest.xml");
			CString sxmlpath = fileName + manfpath;
			char *xmlpath = CStringToChar(sxmlpath);
			tinyxml2::XMLDocument doc;
			doc.LoadFile(xmlpath);


			tinyxml2::XMLElement *RootElement = doc.RootElement();//���Ը�Ԫ��
			tinyxml2::XMLElement *RootSubElements = RootElement->FirstChildElement();//��һ����Ԫ��
			while (RootSubElements)
			{
				const char* application = RootSubElements->Value();
				CString apli;
				apli.Format(_T("%s"), CStringW(application)); //��������װ���ַ�����
				if (apli == "application")
				{
					tinyxml2::XMLElement *elements = RootSubElements->FirstChildElement();//appli

					while (elements)
					{
						const char* metadata = elements->Value();
						CString string;
						string.Format(_T("%s"), CStringW(metadata)); //��������װ���ַ�����
						if (string == "meta-data")//�ҵ���meta-data�ڵ�
						{
							const tinyxml2::XMLAttribute *attr = elements->FirstAttribute();
							while (attr)
							{
								const char* name = attr->Name();
								const char* value = attr->Value();
								CString cname;
								CString cvalue;
								cname.Format(_T("%s"), CStringW(name));
								cvalue.Format(_T("%s"), CStringW(value));
								if (cname == "android:name" && cvalue == strCBText)
								{
									//MessageBox(cvalue);
									elements->SetAttribute("android:value", CStringToChar(id));
									break;
								}
								attr = attr->Next();

							}

						}
						elements = elements->NextSiblingElement();
					}
					doc.SaveFile(xmlpath);

					GetDlgItem(ID_STATE)->SetWindowText(_T("���ڴ������:" + name));
					buildapkinfo.fileName = fileName;
					buildapkinfo.name = name;
					buildapkinfo.hWnd = m_hWnd;

					CString zcmd3 = _T("_Signed");
					CString bapk = _T(".apk");
					DeleteFile(fileName + name + zcmd3 + bapk);

					AfxBeginThread((AFX_THREADPROC)BuildApks, &buildapkinfo);
					break;
				}
				RootSubElements = RootSubElements->NextSiblingElement();
			}

			








			/*
			tinyxml2::XMLElement *RootElement = doc.RootElement();//man
			tinyxml2::XMLElement *elements = RootElement->FirstChildElement()->FirstChildElement();//appli

			while (elements)
			{
				const char* metadata = elements->Value();
				CString string;
				string.Format(_T("%s"), CStringW(metadata)); //��������װ���ַ�����
				if (string == "meta-data")//�ҵ���meta-data�ڵ�
				{
					const tinyxml2::XMLAttribute *attr = elements->FirstAttribute();
					while (attr)
					{
						const char* name = attr->Name();
						const char* value = attr->Value();
						CString cname;
						CString cvalue;
						cname.Format(_T("%s"), CStringW(name));
						cvalue.Format(_T("%s"), CStringW(value));
						if (cname == "android:name" && cvalue == strCBText)
						{
							//MessageBox(cvalue);
							elements->SetAttribute("android:value", CStringToChar(id));
						}
						attr = attr->Next();

					}

				}
				elements = elements->NextSiblingElement();
			}
			doc.SaveFile(xmlpath);

			GetDlgItem(ID_STATE)->SetWindowText(_T("���ڴ������:" + name));
			buildapkinfo.fileName = fileName;
			buildapkinfo.name = name;
			buildapkinfo.hWnd = m_hWnd;

			CString zcmd3 = _T("_Signed");
			CString bapk = _T(".apk");
			DeleteFile(fileName + name + zcmd3 + bapk);

			AfxBeginThread((AFX_THREADPROC)BuildApks, &buildapkinfo);
			*/

		}
		else
		{
			barProgress.SetPos(95);
			GetDlgItem(ID_STATE)->SetWindowText(_T("����ɾ����ʱ�ļ�"));
			DeleteFile(_T("keysinfo.txt"));
			DeleteDirectory(fileName);
			GetDlgItem(ID_STATE)->SetWindowText(_T("���������Ѵ���ɹ�"));
			barProgress.SetPos(100);
			isRun = false;
			MessageBox(_T("���������Ѵ���ɹ���"), _T("��ʾ"));//��ʾʧ��
		}
	}
	else
	{
		char *name = (char *)wParam;
		CString bapk = _T(".apk");
		DeleteFile(fileName + name + bapk);
		DeleteFile(_T("keysinfo.txt"));
		DeleteDirectory(fileName);
		barProgress.SetPos(100);
		isRun = false;
		MessageBox(_T("apkǩ��ʧ�ܣ���ȷ��keystore�����Ƿ���ȷ"), _T("��ʾ"));
	}
	return 0;
}

int CApkBuildDlg::GetProgressStep(CString channelId)
{
	int count = 0;
	char *cnext = NULL;
	char *item;
	item = strtok_s(CStringToChar(channelId), "\n", &cnext);
	while(item)
	{
		count++;
		item = strtok_s(NULL, "\n", &cnext);
	}
	return count;
}

void CApkBuildDlg::GetChannelNames()
{
	GetDlgItem(ID_STATE)->SetWindowText(_T("���ڽ���apk��..."));
	DeleteDirectory(fileName);
	CString apkPath;
	ePath.GetWindowTextW(apkPath);
	CString scmd = _T("apktool apktool d ");
	CString dapkcmd = scmd + apkPath;
	int state = system(CStringToChar(dapkcmd));
	if (state == 0)
	{
		CString manfpath = _T("/AndroidManifest.xml");
		CString sxmlpath = fileName + manfpath;
		char *xmlpath = CStringToChar(sxmlpath);
		tinyxml2::XMLDocument doc;
		doc.LoadFile(xmlpath);

		tinyxml2::XMLElement *RootElement = doc.RootElement();//���Ը�Ԫ��
		tinyxml2::XMLElement *RootSubElements = RootElement->FirstChildElement();//��һ����Ԫ��
		while (RootSubElements)
		{
			const char* application = RootSubElements->Value();
			CString apli;
			apli.Format(_T("%s"), CStringW(application)); //��������װ���ַ�����
			if (apli == "application")
			{
				tinyxml2::XMLElement *elements = RootSubElements->FirstChildElement();//appli

				while (elements)
				{
					const char* metadata = elements->Value();
					CString string;
					string.Format(_T("%s"), CStringW(metadata)); //��������װ���ַ�����
					if (string == "meta-data")//�ҵ���meta-data�ڵ�
					{
						const tinyxml2::XMLAttribute *attr = elements->FirstAttribute();
						while (attr)
						{
							const char* name = attr->Name();
							const char* value = attr->Value();
							CString cname;
							CString cvalue;
							cname.Format(_T("%s"), CStringW(name));
							cvalue.Format(_T("%s"), CStringW(value));
							if (cname == "android:name")
							{
								cbChannelName.AddString(cvalue);
							}
							attr = attr->Next();

						}

					}
					elements = elements->NextSiblingElement();
				}
				cbChannelName.SetCurSel(0);
				int nIndex = cbChannelName.GetCurSel();
				if (nIndex >= 0)
				{
					CString strCBText;
					cbChannelName.GetLBText(nIndex, strCBText);
					DeleteDirectory(fileName);
					if (strCBText == _T(""))
					{
						GetDlgItem(ID_STATE)->SetWindowText(_T("��apk����û������������"));
						MessageBox(_T("��apk����û������������"), _T("��ʾ"));
					}
					else
					{
						GetDlgItem(ID_STATE)->SetWindowText(_T("��ȡ�������Ƴɹ�"));
					}
				}
				else
				{
					GetDlgItem(ID_STATE)->SetWindowText(_T("��apk����û������������"));
					MessageBox(_T("��apk����û������������"), _T("��ʾ"));
				}
				break;
			}
			RootSubElements = RootSubElements->NextSiblingElement();
		}
		
	}
	else
	{
		MessageBox(_T("apk������ʧ��"), _T("��ʾ"));
	}
}


void CApkBuildDlg::OnBnClickedChannelname()
{

	
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	if (isRun)
	{
		return;
	}
	CString filepath = GetAllChannelDialog();
	if (filepath == _T(""))
	{
		return;
	}

	CFile fFile(filepath, CFile::modeRead);
	CStringA strFile;
	fFile.Read(strFile.GetBufferSetLength(fFile.GetLength()), fFile.GetLength());
	fFile.Close();
	strFile.ReleaseBuffer();
	CString result = CString(strFile);
	eChannelID.SetWindowTextW(result);
	//CompressionApk();
}

void CApkBuildDlg::CompressionApk()
{
	
	CString filepath = fileName +  _T("/apktool.yml");
	CFile fFile(filepath, CFile::modeRead);
	CStringA strFile;
	fFile.Read(strFile.GetBufferSetLength(fFile.GetLength()), fFile.GetLength());
	fFile.Close();
	strFile.ReleaseBuffer();
	CString result = CString(strFile);
	DeleteFile(filepath);
	CStdioFile file;
	file.Open(filepath, CFile::modeCreate | CFile::modeWrite | CFile::typeText);

	CString apktoolxml;

	char *xmlpath = CStringToChar(result);
	char *pNext = NULL;
	char *p = strtok_s(xmlpath, "\n", &pNext);
	while (p)
	{
		CString string;
		string.Format(_T("%s"), CStringW(p)); //��������װ���ַ�����
		if (string == _T("doNotCompress:"))
		{
			p = strtok_s(NULL, "\n", &pNext);
			continue;
		}
			
		int index = string.Find(_T("-"));
		if (index == 0)
		{
			p = strtok_s(NULL, "\n", &pNext);
			continue;
		}
		file.WriteString(string + "\n");
		p = strtok_s(NULL, "\n", &pNext);
	}
	file.Close();
}

int CApkBuildDlg::IncludeChinese(char *str)
{
	int nRet = 0;
	char c;
	while (c = *str++)
	{
		//����ַ���λΪ1����һ�ַ���λҲ��1���������ַ�
		if ((c & 0x80) && (*str & 0x80))
		{
			nRet = 1;
			break;
		}
	}
	return nRet;
}
